The instruction for deployment.
1. Devices:
- TPYBoard firmware download
- wiring between devices and sensors&communication module(LoRa)
2. Gateway:
- RaspberryPi operating system download and sd card setup
- wiring between RaspberryPi and LoRa module, 2G GSM module
- third party libs installation(virtualenv, pip3, python3, hbmqtt, etc)
- project running
3. Could:
- server machine preparation and setting
- software installation(Docker, Django, MySQL, etc)
- DNS, IP address setting
- server running
