System architecture repository.
