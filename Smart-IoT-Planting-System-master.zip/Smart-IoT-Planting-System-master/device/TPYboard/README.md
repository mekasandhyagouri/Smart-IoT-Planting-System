TPYBoard hardware specification repository.  
Include Pin diagram, board information.  
The end device is running on TPYboard base on STM32 mcu.
