#calc the battery by ADC 
