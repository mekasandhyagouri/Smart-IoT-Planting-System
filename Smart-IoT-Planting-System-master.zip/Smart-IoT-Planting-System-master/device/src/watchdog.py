#Detect device status, if errors, reboot by watchdog.
#Send on-line message to gateway while bootup, if gateway receive plenty of 
#on-line messages in a short time from the same device, an alarm occurs.
