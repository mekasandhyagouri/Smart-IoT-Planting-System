#!/usr/bin/env python
#Features as below:
#1. Detect the battery's power left via ADC port.
#2. Check the device on-line or off-line status by LoRa heartbeat.  

