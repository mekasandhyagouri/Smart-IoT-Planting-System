Django 1.10 web application, user attend platform via browser(PC, phone, tablet).
Browser shows the data from sensor, devices status, and other information.Besides, user
can set the system and send commands to devices via browser.
Components:
- Django 1.10 framework
- MySQL database
- Bootstrap font-end framework
- jQuery, Ajax (support notification)
- JSON parser
- Visualization framework
