mysql -u root -p

>CREATE DATABASE sips;

>show databases;

>use sips;

>show tables;
