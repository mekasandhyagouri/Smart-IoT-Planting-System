Django and mqtt_server deploy method.
Install pip,virtualenv,Django,Docker,MySQL,hbmqtt,etc.
Run Django server and hbmqtt server.

Provide the mothod of deploying on SAE, ali server, CentOS server, local virmware+ubuntu.

