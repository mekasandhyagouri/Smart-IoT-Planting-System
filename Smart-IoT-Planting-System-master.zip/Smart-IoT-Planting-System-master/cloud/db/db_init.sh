#/bin/sh
#install mysql

#create database
mysql -u root -p
