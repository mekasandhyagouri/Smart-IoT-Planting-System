#!/bin/sh
#launch hbmqtt server
hbmqtt -d #debug model
