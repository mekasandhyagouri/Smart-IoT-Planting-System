MQTT server based on hbmqtt.   
Gateway communicate with cloud via MQTT protocol,browser communicate with cloud via HTTP based on Django.   
Django communicate with mqtt_server via database.

