Gateway hardware platform specification.   
In this demo project, we use Raspberry Pi 3B.
The default Python version is 2.7.9, we need to upgrade it to 3.5 as to support coroutine and ansyncio.
Gateway hardware list:
- Raspberry Pi 3B   
![Alt text](https://github.com/Python-IoT/Smart-IoT-Planting-System/blob/master/gateway/hardware/RaspberryPi-3B.jpg)
- LoRa module(E32-TTL-100)   
![Alt text](https://github.com/Python-IoT/Smart-IoT-Planting-System/blob/master/gateway/hardware/LoRa-module.png)
- GSM module(GA6)    
![Alt text](https://github.com/Python-IoT/Smart-IoT-Planting-System/blob/master/gateway/hardware/GSM-module.png)

