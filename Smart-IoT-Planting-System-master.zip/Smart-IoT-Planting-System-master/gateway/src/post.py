#!/usr/bin/env python
import requests
HTTP POST message to cloud platform
#Most times gateway communicate with cloud via MQTT(hbmqtt framework),  
#in some special time, it need to use HTTP(requests framework) to POST message to cloud.
