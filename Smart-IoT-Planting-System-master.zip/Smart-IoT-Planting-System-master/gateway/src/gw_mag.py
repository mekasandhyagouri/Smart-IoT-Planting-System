#Gateway management.
#Check gateway CPU temperature, on-line status via hbmqtt heartbeat, show its location on map via GPS in 2G module.
