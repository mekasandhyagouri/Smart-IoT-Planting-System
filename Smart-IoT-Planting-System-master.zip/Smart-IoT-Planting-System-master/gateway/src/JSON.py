#Parse JSON from devices via LoRa and from server via MQTT or HTTP.
