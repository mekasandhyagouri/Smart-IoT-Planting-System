#Message queue for LoRa and threading task.
