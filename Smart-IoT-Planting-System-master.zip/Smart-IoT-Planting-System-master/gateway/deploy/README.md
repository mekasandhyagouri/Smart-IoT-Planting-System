Application software for gateway need several third library,
so we need several tools to deploy the application, such as pip3, virturalenv, Docker, etc.
In this prototype, we used Raspberry Pi 3B as the hardware platform, the default Python version
is 2.7, but hbmqtt only support Python 3.4, so we need to upgrade Python to 3.5.1.
